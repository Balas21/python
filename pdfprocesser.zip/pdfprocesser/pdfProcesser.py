import json
import base64
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv
import os
import re
import io
import fitz
from util.sequanceGenerater import generate_sequance
from  connectionqueue.azureQueueConnection import get_queue_client
from dao.dao import insertData

load_dotenv()

#get PDF from Azure Storage Account -----
def get_pdf_name(message):
     decoded_message=base64.b64decode(message.content).decode('utf-8')
     #print(f"Message Content :{decoded_message}")         
     json_data=json.loads(decoded_message)
     storage_url= json_data.get("data",{}).get("url")
     print(f"storage_url :{storage_url}") 
     pdf_name=trim_get_pdf_name(storage_url)
     print(f"pdf_name :{pdf_name}") 
     return pdf_name
    
def read_blob_data():
     queue_client=get_queue_client(os.getenv("QUEUE_NAME"))
     message=queue_client.receive_message()
     if message:
               #for messsage in messages:
          decoded_message=base64.b64decode(message.content).decode('utf-8')
          pdf_name=get_pdf_name(message)
          #move Mesage to different queue
          #des_queue_client.send_message(decoded_message) 
          #delete Message 
          queue_client.delete_message(message.id,message.pop_receipt)   
          try:
               blob_service_client=BlobServiceClient.from_connection_string(os.getenv("CONNECTION_STRING"))
               blob_client=blob_service_client.get_blob_client(container=os.getenv("UNPROCESSED_FILE_LOCATION"),blob=pdf_name)
               blob_data=blob_client.download_blob().readall()
               ##Pass blob Service Client and blob stream data to the Method
               #redact_pdf(blob_data,blob_service_client,pdf_name)
               return blob_data , pdf_name
          except Exception as e:
               print(f"Error while Reading PDF : {e}")
     return None,None


def trim_get_pdf_name(storage_url):
    pattern=r'[^/]+\.pdf$'
    match=re.search(pattern,storage_url)
    if match:
        pdf_name= match.group(0)
        print(f'PDF NAME :{pdf_name}')
        return pdf_name
    return None

def read_pdf(blob_data):
    #Open PDF document using FITZ
    doc=fitz.open(stream=blob_data,filetype="pdf")
    return doc

def upload_pdf(doc,pdf_name):
    io_stream=io.BytesIO()
    doc.save(io_stream)
    doc.close()
    io_stream.seek(0)
    if io_stream:
     try:
            seqNo=generate_sequance()
            pdf_name=f"{seqNo}-{pdf_name}"
            print(f'Pdf Name after Amending Sequance : {pdf_name}')
            blob_service_client=BlobServiceClient.from_connection_string(os.getenv("CONNECTION_STRING"))
            c_client=blob_service_client.get_container_client(os.getenv("PROCESSED_FILE_LOCATION"))
            b_client=c_client.get_blob_client(pdf_name)
            b_client.upload_blob(io_stream,overwrite=True)
            return seqNo,pdf_name
     except Exception as e:
         print(f"Exception {e}")
         e
     return None,None