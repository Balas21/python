from azure.storage.queue import QueueServiceClient
import base64
import json
import re
import io
import time
from azure.storage.blob import BlobServiceClient
from PyPDF2 import PdfReader
from dotenv import load_dotenv
import os

#Load data ENV
load_dotenv()

#Connect Azure Storage Queue:
def connect_to_queue_client():
    try:
        queue_service_client=QueueServiceClient.from_connection_string(os.getenv("CONNECTION_STRING"))
        print("Connected to Azure Storage Queue!!!! :) :)")
        return queue_service_client
    except Exception as e:
        print(f"Error conencting Azure Storage Queue : {e}")
        return None
    
def connect_to_queue(queue_name): 
    try:
     queue_service_client = connect_to_queue_client()
     if queue_service_client:
        queue_client=queue_service_client.get_queue_client(queue_name)
        return queue_client
    except Exception as e:
         print(f"Error conencting Azure Storage Queue for Queue Name: {e},{queue_name}")
         return None
    return None

def get_queue_client(queue_name):
    queue_client =connect_to_queue(queue_name)
    if queue_client:
     return queue_client
    return None
    
       




