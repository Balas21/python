import time
from dotenv import load_dotenv
from pdfprocesser.pdfProcesser import read_blob_data ,read_pdf,upload_pdf
import os
import spacy
from dao.dao import insertData,readData
from piiredact.RedactMain import addRules

nlp = spacy.load("en_core_web_trf")
nlp=addRules(nlp)


load_dotenv()


def main():
    text = "John who has Born on 21 Nov 1990  and Born: 21-11-1990 has a history of hypertension and type 2 diabetes No history of surgeries or major  illnesses and email b@nhs.co.uk and phone 017-37-0234 redhill uk"
    doc = nlp(text)                    
    for ent in doc.ents:
        if ent.label_ in ["PERSON", "ORG", "APPLICATION_NUMBER","DATE","DOB","UK_POST_CODE","C_DOB","C_EMAIL","C_PHONE"]:
          print(f'Enitity type : {ent.label_}-{ent.text}')


if __name__=="__main__":main()