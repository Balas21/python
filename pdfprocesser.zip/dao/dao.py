from azure.data.tables import TableServiceClient
from azure.core.exceptions import ResourceExistsError
from dotenv import load_dotenv
import os


load_dotenv()
 
def insertData(json_data,sequanceNo):
    try:
        tableServiceClient=TableServiceClient.from_connection_string(os.getenv("CONNECTION_STRING"))
        tabble_clinet=tableServiceClient.get_table_client(os.getenv("PII_TABLE_NAME"))
        tabble_clinet.upsert_entity(json_data)
        print("Record Insterted")
    except Exception as e:
        print(f"Exception while inserting Record {e}")


def readData(partition_key):
    tableServiceClient=TableServiceClient.from_connection_string(os.getenv("CONNECTION_STRING"))
    tabble_clinet=tableServiceClient.get_table_client(os.getenv("PII_TABLE_NAME"))
    filter_query = "PartitionKey eq 'PPIDATA'"
    entites=tabble_clinet.query_entities(query_filter=filter_query)  
    


