import time
from dotenv import load_dotenv
from pdfprocesser.pdfProcesser import read_blob_data ,read_pdf,upload_pdf
import os
from dao.dao import insertData,readData
from piiredact.RedactMain import redact_pii_data
import json


load_dotenv()


def main():
    polling_interval=10
    while True:        
        blob_data,pdf_name =read_blob_data()
        if blob_data:
            doc=read_pdf(blob_data)
            #print(f'read Pdf completed {len(doc)}') 
            pii_json=[]               
            redact_pii_data(doc,pii_json)           
            seq_no,redact_pdf_name=upload_pdf(doc,pdf_name)
            json_data={
                "fileName":pdf_name , 
                "processedFileName": redact_pdf_name,
                "PartitionKey":"PPIDATA",
                "RowKey":str(seq_no),
                "piiData":json.dumps(pii_json,indent=4)              
            }
            insertData(json_data,seq_no)
        readData("PPIDATA")
        time.sleep(polling_interval)


if __name__=="__main__":main()