from datetime import datetime

def generate_sequance():
    date_str=datetime.now().strftime("%Y%m%d")
    timestamp=int(datetime.now().timestamp())
    sequance = f"{date_str}-{timestamp}"
    print(f"sequance :{sequance}")
    return sequance