import fitz
from util.JsonGenerater import preparePIIOutPut

def redact_pii_text(page,nlp,pii_json,page_num):
   
    text_blocks = page.get_text("dict")["blocks"]
    
    for block in text_blocks:
        if "lines" in block:
            for line in block["lines"]:
                for span in line["spans"]:
                    text = span["text"]
                    bbox = fitz.Rect(span["bbox"])
                    
                    # Detect PII using spaCy
                    doc = nlp(text)                    
                    for ent in doc.ents:
                        if ent.label_ in ["PERSON", "APPLICATION_NUMBER","DOB","UK_POST_CODE","EMIAL","GPE","C_EMAIL","C_PHONE","NHS"]:
                           for rect in page.search_for(ent.text): 
                            page.add_redact_annot(rect,fill=(0, 0, 0))  # mark as "remove this"
                            pii_json.append(preparePIIOutPut(page_num,ent.text,ent.label_ )) 

    page.apply_redactions()   