from spacy.language import Language
from spacy.tokens import Span
import re


def isDOBPatternMatch(ent,doc):
        org_token=""
        dob_pattern=re.compile(r"^(birth|born\s*:?|born\s+on\s*:|dob\s*:|date\s+of\s+birth\s+on|Bornon)\b[\s:]$",re.IGNORECASE)
        dob_pattern1=re.compile(r"^(Bornon)",re.IGNORECASE)
        for  i in range(1,10) : 
                if ent.start-i >= 0:
                        prev_token=doc[ent.start-i]
                        if prev_token:
                                org_token=prev_token.text+org_token                               
                                if(dob_pattern.match(org_token.strip()) or dob_pattern1.match(org_token.strip())):
                                        return True
        return False

        


        

@Language.component("expend_person_entities")
def expand_person_entites(doc):        
        new_ents=[]
        person_title_pattern=re.compile(r"^(Dr|Mr|Mrs|Ms|name|foreeName|Surname|)\.?$",re.IGNORECASE)       

        for ent in doc.ents:
                if ent.label_=="PERSON" and ent.start !=0:
                        prev_token=doc[ent.start-1]
                        if(person_title_pattern.match(prev_token.text.strip())):
                                new_ent=Span(doc,ent.start-1,ent.end,label=ent.label)
                                new_ents.append(new_ent)
                        else:
                            new_ents.append(ent)
        for ent in doc.ents:
                if ent.label_=="DATE" and ent.start !=0:                       
                        if isDOBPatternMatch(ent,doc):                                
                                new_ent=Span(doc,ent.start-1,ent.end,label='DOB')
                                new_ents.append(new_ent)
                        else:
                            new_ents.append(ent)  
        
        doc.ents= new_ents
        return doc

@Language.component("expend_post_code")
def expand_psotcode(doc):
        new_ents=[]
        post_code=re.compile(r'\b([A-Z]{1,2}[0-9][A-Z0-9]?\s?[0-9][A-Z]{2})\b',re.IGNORECASE)
        for ent in doc.ents:
                if ent.label=="GPE" and ent.start !=0:
                        prev_token=doc[ent.start-1]
                        if(post_code.match(prev_token.text.strip())):
                                new_ent=Span(doc,ent.start-1,ent.end,label="POSTCODE")
                                new_ents.append(new_ent)
                        else:
                            new_ents.append(ent)        
        doc.ents= new_ents
        return doc 

def is_dob_context(text, match):
    # Check if the date is mentioned in the context of a DOB
    context_keywords = ["birth", "born", "dob", "date of birth"]
    context_window = 20  # Number of characters to check around the match
    start = max(0, match.start() - context_window)
    end = min(len(text), match.end() + context_window)
    context = text[start:end].lower()
    return any(keyword in context for keyword in context_keywords)

@Language.component("regex_pii_matcher")
def regex_pii_matcher(doc):
    """
    Identifies PII in the text using regex patterns and assigns custom labels.
    """
    # Define regex patterns for PII
    patterns = [
          (r"\b[A-Z]{2}\d{6,}\b", "APPLICATION_NUMBER") ,
          (r'\b([A-Z]{1,2}[0-9][A-Z0-9]?\s?[0-9][A-Z]{2})\b',"UK_POST_CODE") ,
         (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',"C_EMAIL"),
         (r'\b\d{4}-\d{6}\b',"C_PHONE"),
         (r'\b\d{3}\s\d{3}\s\d{4}\b',"NHS")                  
         
    ] 
    

    # Create spans for matches
    matches = []
    for pattern, label in patterns:
        for match in re.finditer(pattern, doc.text):           
            start_char, end_char = match.span()
            # Use doc.char_span to map character offsets to token indices
            span = doc.char_span(start_char, end_char, label=label)           
            if span:  # Ensure span is valid (not crossing token boundaries)
                matches.append(span)

    # Attach matches as entities
    doc.ents = list(doc.ents) + matches
    return doc


def addRules(nlp):  
     nlp.add_pipe("expend_person_entities", after="ner") 
     nlp.add_pipe("regex_pii_matcher", last=True)
     return nlp