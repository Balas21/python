import fitz
import spacy
from piiredact.textRedacter import redact_pii_text
from piiredact.entity_rules import addRules
from piiredact.imageRedacter import process_images
nlp = spacy.load("en_core_web_trf")
addRules(nlp)

def  redact_pii_data(doc,pii_json): 
        
    print(f"No of pages in the PDF is {len(doc)}")
    # page_num    
    for page_num in range(len(doc)):
        print(f'Processing PII Redact for the Page Number {page_num}')
        page = doc[page_num] 
        redact_pii_text(page,nlp,pii_json,page_num) 
        process_images(page,"output_images1",page_num,nlp,pii_json)      
    