import fitz  # PyMuPDF
from PIL import Image, ImageDraw
import pytesseract
import io
import spacy  # Load spaCy model
import os  # To handle saving files
from spacy.matcher import Matcher
from spacy.tokens import Span
from spacy.pipeline import EntityRuler
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'  # Update this path as needed
from util.JsonGenerater import preparePIIOutPut



 
  


def redact_pii_image(image, page_number, img_index, output_folder,nlp,pii_json):
    # OCR to extract text and bounding box data
    ocr_result = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
    ocr_text = " ".join(ocr_result['text'])    
    #["Jhon","","Parker"]
    #jhon Parker - PERSON
    # Use SpaCy to identify entities
    doc = nlp(ocr_text)
    
    # Prepare to draw on the image
    draw = ImageDraw.Draw(image)
    
    # Process each entity detected by SpaCy
    for ent in doc.ents:        
        # Only redact specific types of entities
         if ent.label_ in ["PERSON", "APPLICATION_NUMBER","DOB","UK_POST_CODE","C_EMAIL","C_PHONE","NHS"]:
            # Normalize entity text for matching
            entity_text = ent.text.lower().strip()
            if ent.label_ =="DOB":
                entity_text=entity_text.replace(": ","")            
            matched_boxes = []
            # Sliding window to find multi-word matches in OCR output
            for i in range(len(ocr_result['text'])):
                ocr_phrase = ""
                box_coords = []                
                for j in range(i, len(ocr_result['text'])):                    
                    word = ocr_result['text'][j].strip()
                    if(word.lower()==entity_text):
                        matched_boxes.append(j)
                        break  
                    if word == "":
                        continue         

                    
                    # Build the OCR phrase incrementally
                    ocr_phrase += ("" if ocr_phrase == "" else " ") + word.lower()
                    box_coords.append(j)
                    # Break if the phrase matches the entity text
                    if ocr_phrase == entity_text:
                        matched_boxes = box_coords
                        break
                
                if matched_boxes:
                    pii_json.append(preparePIIOutPut(page_number,ent.text,ent.label_ ))
                    break
            
            # If a match is found, compute the bounding box and redact
            if matched_boxes:
                x_min = min(ocr_result['left'][idx] for idx in matched_boxes)
                y_min = min(ocr_result['top'][idx] for idx in matched_boxes)
                x_max = max(ocr_result['left'][idx] + ocr_result['width'][idx] for idx in matched_boxes)
                y_max = max(ocr_result['top'][idx] + ocr_result['height'][idx] for idx in matched_boxes)
                
                # Draw a black rectangle over the detected entity
                draw.rectangle([x_min, y_min, x_max, y_max], fill="black")
                #print(f"Redacted entity: {ent.text}, Bounding box: [{x_min}, {y_min}, {x_max}, {y_max}]")

    # Save the redacted image
    redacted_image_path = f"{output_folder}/redacted_page_{page_number}_img_{img_index}.png"
    image.save(redacted_image_path)
    
    # Save the redacted image separately in the specified output folder
    redacted_image_path = os.path.join(output_folder, f"redacted_page_{page_number}_image_{img_index}.png")
    image.save(redacted_image_path)
    return redacted_image_path

def process_images(page, output_folder, page_number,nlp,pii_json):
    images = page.get_images(full=True)    
    for img_index, img in enumerate(images):
        xref = img[0]  # Reference to the image (image xref)
        base_image = page.parent.extract_image(xref)
        image_bytes = base_image["image"]
        image_ext = base_image["ext"]
        
        # Open the image using Pillow
        image = Image.open(io.BytesIO(image_bytes))
        
        # Redact PII in the image
        redacted_image_path = redact_pii_image(image, page_number, img_index, output_folder,nlp,pii_json)
        
        # Save the redacted image to bytes
        img_stream = io.BytesIO()
        redacted_image = Image.open(redacted_image_path)
        redacted_image.save(img_stream, format=image_ext.upper())  
        img_stream.seek(0)        
        page.replace_image(xref,filename=None, pixmap=None, stream=img_stream) 